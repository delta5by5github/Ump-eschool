# w3schools-Clone
This is a clone of w3shools site
It's made using css , javascript and html with some small use of jquery and bootstrap.
